/***********************************************************************
 * 实验名称：串口数据通信实验
 *
 * 实验准备：龙芯1C102开发板、TTL-串口模块、杜邦线
 *
 * 硬件接线：使用TTL-串口模块和杜邦线连接龙芯1C102开发板开发板与PC端
 *          TTL-串口模块--------龙芯1C102开发板开发板
 *             TXD      -------     GPIO_06
 *             RXD      -------     GPIO_07
 *             GND      -------      GND
 *
 * 实验现象：通过TTL-串口模块与PC端连接，实现数据自发自收。
 *          PC端使用串口助手软件，可以看到串口0接收到的数据。
 *          PC端发送数据到串口0，串口0接收到的数据。
 *
 * 注意事项：串口助手配置为115200波特率，8位数据位，无校验位，1位停止位。
 *          串口发送时，需要选择为HEX模式，否则会出现乱码。
 **************************************************************************/
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "ls1x_common.h"
#include "ls1x_gpio.h"
#include "ls1x_exti.h"
#include "ls1x_latimer.h"
#include "ls1x_rtc.h"
#include "ls1c102_touch.h"
#include "ls1x_string.h"
#include "ls1x_wdg.h"
#include "ls1x_uart.h"
#include "ls1x_spi.h"
#include "ls1c102_i2c.h"
#include "ls1x_uart.h"
#include "ls1x_clock.h"
#include "UserGpio.h"
#include "Config.h"
#include "oled.h"
#include "queue.h"
#include "ls1c102_interrupt.h"

void dance();
char str[50];
uint8_t received_data = 0;
extern Sex,Min,Hour;
extern Sex1,Min1,Hour1;
extern mode;

int main(int arg, char *args[])
{
	int flag=0;
	int key_value;
    /*uint8_t temperature = 0, temperatureL = 0;
    uint8_t humidity = 0, humidityL = 0;*/
 
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    IIC_Init();
    OLED_Init();
    EnableInt(); // 开总中断
    Queue_Init(&Circular_queue);
    BEEP_Init();
	
    Uart1_init(115200); // 串口0初始化，io06 io07   串口初始化需要在开启EnableInt之后
	
    timer_init(1000); //设置定时器周期为1000ms
	//int32_t Hour1=16,Min1=29,Sex1=10;
	//OLED_Show_Str( 60, 0, "mode:", 16);
	

	//OLED_ShowInt32Num(100, 0, mode, 1, 16);
	while(1)
	{
	
		
		key_value = KEY_Check();
        switch(key_value)
        {
            case 1:mode++;if(mode>2)mode=1;
            break;
		}
		if(mode==2)
		{
				switch(key_value)
			{
				case 2:mode++;if(mode>2)mode=1;
				break;
			}
		}
		switch(key_value)
        {
            case 3:Sex++;			//1秒到，Sec自增
				if(Sex>=60)
				{
					Sex=0;		//60秒到，Sec清0，Min自增
					Min++;
					if(Min>=60)
					{
						Min=0;	//60分钟到，Min清0，Hour自增
						Hour++;
						if(Hour>=24)
						{
							Hour=0;	//24小时到，Hour清0
						}
					}
				}
            break;
            case 4:Sex--;			//1秒到，Sec自增
				if(Sex<60)
				{
					Sex=59;		//60秒到，Sec清0，Min自增
					Min--;
					if(Min<60)
					{
						Min=59;	//60分钟到，Min清0，Hour自增
						Hour--;
						if(Hour<0)
						{
							Hour=23;	//24小时到，Hour清0
						}
					}
				}
            break;
		}
		
			if( gpio_get(GPIO_PIN_18))
			{
				dance();
			}
		
		
			flag=gpio_get(GPIO_PIN_17);
			if(flag==1)
			{
				gpio_up(GPIO_PIN_16);
				delay_ms(500);
			}
			else
			{
				gpio_low(GPIO_PIN_16);
				
				delay_ms(500);
			}
			flag=0;
	}
	

	
	

    
	
    /*while (1)
    {

        if (Queue_isEmpty(&Circular_queue) == 0) // 判断队列是否为空，即判断是否收到数据
        {
            Read_length = Queue_HadUse(&Circular_queue); // 返回队列中数据的长度
             memset(Read_Buffer, 0, DATA_LEN);//填充接收缓冲区为0
            Queue_Read(&Circular_queue, Read_Buffer, Read_length); // 读取队列缓冲区的值到接收缓冲区
            OLED_Show_Str(40, 6, Read_Buffer, 16);
        }
        else
        {
            memset(Read_Buffer, 0, DATA_LEN); // 填充接收缓冲区为0
        }
		
        delay_ms(1000);
    }
 
    return 0;
}
void dance()
{
	Uart1_send("{#000P1500T0400!#001P1600T0400!#002P1600T0400!#003P1500T0400!#004P1600T0400!#005P1600T0400!}");
	delay_ms(400);
	Uart1_send("{#000P1500T0400!#001P1400T0400!#002P1400T0400!#003P1500T0400!#004P1400T0400!#005P1400T0400!}");
	delay_ms(400);
	Uart1_send("{#000P1500T0400!#001P1600T0400!#002P1600T0400!#003P1500T0400!#004P1600T0400!#005P1600T0400!}");
	delay_ms(400);
	Uart1_send("{#000P1500T0400!#001P1400T0400!#002P1400T0400!#003P1500T0400!#004P1400T0400!#005P1400T0400!}");
	delay_ms(400);
	Uart1_send("{#000P1500T1000!#001P1500T1000!#002P1500T1000!#003P1500T1000!#004P1500T1000!#005P1500T1000!}");
	delay_ms(1400);
	Uart1_send("{#000P1500T1000!#001P1500T3000!#002P1500T3000!#003P2000T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send("{#000P1500T1000!#001P1500T3000!#002P1500T3000!#003P1500T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send("{#000P1000T1000!#001P1500T3000!#002P1500T3000!#003P1500T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send("{#000P1500T1000!#001P1500T3000!#002P1500T3000!#003P1500T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send("{#000P1650T1000!#001P1500T3000!#002P1500T3000!#003P1700T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
//zx_uart_send_str((u8 *) "{#000P1300T1000!#001P1500T3000!#002P1500T3000!#003P1300T1000!#004P1500T3000!#005P1500T3000!}");
//	delay_ms(1500);
//	
	Uart1_send( "{#000P1500T1000!#001P1500T3000!#002P1500T3000!#003P1500T1000!#004P1500T1000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send("{#000P1500T3000!#001P1500T3000!#002P1500T3000!#003P1300T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send("{#000P1300T1000!#001P1500T3000!#002P1500T3000!#003P1300T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send( "{#000P1500T1000!#001P1500T3000!#002P1500T3000!#003P1500T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send( "{#000P1700T1000!#001P1500T3000!#002P1500T3000!#003P1500T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send( "{#000P1700T1000!#001P1500T3000!#002P1500T3000!#003P1700T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send( "{#000P1500T1000!#001P1500T3000!#002P1500T3000!#003P1500T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send( "{#000P1500T1000!#001P1200T1000!#002P1500T3000!#003P1500T1000!#004P1800T1000!#005P1500T3000!}");
	delay_ms(1500);
	Uart1_send( "{#000P1500T1000!#001P1500T3000!#002P1500T3000!#003P1500T1000!#004P1500T3000!#005P1500T3000!}");
	delay_ms(1500);
}