#ifndef __BEEP_H
#define __BEEP_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ls1x.h"


#define BEEP        GPIO_PIN_63
#define BEEP_ON     gpio_write_pin(BEEP, 1)
#define BEEP_OFF    gpio_write_pin(BEEP, 0)

void BEEP_Init(void);
void LED_slash(int gpio_num);
int gpio_get(int PIN_num);
void gpio_low(int pin_num);
void gpio_up(int pin_num);
#ifdef __cplusplus
}
#endif

#endif // __KEY_H
