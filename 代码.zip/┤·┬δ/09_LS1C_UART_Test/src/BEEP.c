#include "BEEP.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"

void BEEP_Init(void)
{
    /*gpio_set_direction(BEEP, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_19, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_18, GPIO_Mode_In);
    gpio_set_direction(GPIO_PIN_17, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_16, GPIO_Mode_In);
    gpio_set_direction(GPIO_PIN_4, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_3, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_5, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_61, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_62, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_55, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_54, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_53, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_56, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_45, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_46, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_47, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_44, GPIO_Mode_Out);*/
    gpio_set_direction(GPIO_PIN_17, GPIO_Mode_In);
    gpio_set_direction(GPIO_PIN_16, GPIO_Mode_Out);
    gpio_set_direction(GPIO_PIN_18, GPIO_Mode_In);
    gpio_set_direction(GPIO_PIN_34, GPIO_Mode_Out);
}

void LED_slash(int gpio_num)
{
    gpio_write_pin(gpio_num,1);
    delay_ms(500);
    gpio_write_pin(gpio_num,0);
    delay_ms(500);
}
int gpio_get(int PIN_num)
{
    return gpio_get_pin(PIN_num);
}
void gpio_up(int pin_num)
{
    gpio_write_pin(pin_num,1);
}
void gpio_low(int pin_num)
{
    gpio_write_pin(pin_num,0);
}